﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Stud_management;

namespace Stud_management.Controllers
{
    public class StudentsController : Controller
    {
        private StudentMVCDBEntities1 db = new StudentMVCDBEntities1();

        // GET: Students
        public ActionResult Index()
        {
            var students = db.Students.Include(s => s.Class).Include(s => s.Course);
            return View(students.ToList());
        }

        // GET: Students/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Student student = db.Students.Find(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        public ActionResult FilterStudents()
        {
            ViewBag.class_id = new SelectList(db.Classes, "class_id", "class_name");
            ViewBag.course_id = new SelectList(db.Courses, "course_id", "course_name");
            return View();
        }

        [HttpPost]
        public ActionResult FilterStudents(int? class_id, int? course_id)
        {
            var students = db.Students.AsQueryable();

            if (class_id != null)
                students = students.Where(s => s.class_id == class_id);

            if (course_id != null)
                students = students.Where(s => s.course_id == course_id);

            ViewBag.class_id = new SelectList(db.Classes, "class_id", "class_name", class_id);
            ViewBag.course_id = new SelectList(db.Courses, "course_id", "course_name", course_id);

            return View(students.ToList());
        }

        public ActionResult SearchByBirthYear()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SearchByBirthYear(int year)
        {
            var students = db.Students
                .Where(s => s.dob.HasValue && s.dob.Value.Year == year)
                .ToList();

            ViewBag.Year = year;
            return View(students);
        }

        // Add this method to your StudentController.cs

        //public ActionResult CourseReport()
        //{
        //    var report = db.Courses
        //        .Select(c => new CourseReportViewModel
        //        {
        //            CourseName = c.course_name,
        //            StudentCount = c.Students.Count()
        //        })
        //        .ToList();

        //    return View(report);
        //}

        // GET: Students/Create
        public ActionResult Create()
        {
            ViewBag.class_id = new SelectList(db.Classes, "class_id", "class_name");
            ViewBag.course_id = new SelectList(db.Courses, "course_id", "course_name");
            return View();
        }

        // POST: Students/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "rollno,name,class_id,course_id,email,mobile,dob")] Student student)
        {
            if (ModelState.IsValid)
            {
                db.Students.Add(student);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.class_id = new SelectList(db.Classes, "class_id", "class_name", student.class_id);
            ViewBag.course_id = new SelectList(db.Courses, "course_id", "course_name", student.course_id);
            return View(student);
        }

        // GET: Students/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Student student = db.Students.Find(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            ViewBag.class_id = new SelectList(db.Classes, "class_id", "class_name", student.class_id);
            ViewBag.course_id = new SelectList(db.Courses, "course_id", "course_name", student.course_id);
            return View(student);
        }

        // POST: Students/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "rollno,name,class_id,course_id,email,mobile,dob")] Student student)
        {
            if (student.dob == null || student.dob == default(DateTime))
            {
                ModelState.AddModelError("dob", "Date of birth is required");
                return View(student);
            }
            if (student.dob > DateTime.Today)
            {
                ModelState.AddModelError("dob", "Date of birth cannot be in the future");
                return View(student);
            }

            // Check minimum age (15 years)
            var minimumAge = 15;
            var today = DateTime.Today;
            var age = today.Year - student.dob.Value.Year;  // Use .Value to access the DateTime
            if (student.dob > DateTime.Today.AddYears(-age))
                age--;

            if (age < minimumAge)
            {
                ModelState.AddModelError("dob", $"Student must be at least {minimumAge} years old");
                return View(student);
            }

            if (ModelState.IsValid)
            {
                var studentInDb = db.Students.Find(student.rollno);
                if (studentInDb == null)
                {
                    return HttpNotFound();
                }

                studentInDb.email = student.email;
                studentInDb.mobile = student.mobile;
                studentInDb.dob = student.dob;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.class_id = new SelectList(db.Classes, "class_id", "class_name", student.class_id);
            ViewBag.course_id = new SelectList(db.Courses, "course_id", "course_name", student.course_id);
            return View(student);
        }

        // GET: Students/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Student student = db.Students.Find(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        // POST: Students/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Student student = db.Students.Find(id);
            db.Students.Remove(student);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
