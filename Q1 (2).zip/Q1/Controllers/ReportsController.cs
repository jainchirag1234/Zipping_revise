﻿using Stud_management.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Stud_management.Controllers
{
    public class ReportsController : Controller
    {
       StudentMVCDBEntities1 db = new StudentMVCDBEntities1();
        // GET: Reports
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CourseReport()
        {
            var report = db.Courses
        .Select(c => new CourseReportViewModel
        {
            CourseId = c.course_id,
            CourseName = c.course_name,
            StudentCount = db.Students.Count(s => s.course_id == c.course_id)
        })
        .ToList();

            return View(report);
        }
    }
}