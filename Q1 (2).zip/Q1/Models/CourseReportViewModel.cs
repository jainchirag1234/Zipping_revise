﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stud_management.Models
{
    public class CourseReportViewModel
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public int StudentCount { get; set; }
    }
}